# Jigyasa Daily Content Package — 2026-10-25

Four original Hindi/Hinglish educational infographics for the Jigyasa page, with a JPG and JSON sidecar for each India-time slot.

## Posts

- `content/2026-10-25/08-00.jpg` + `08-00.json` — Sexual response: body and nervous-system changes
- `content/2026-10-25/13-00.jpg` + `13-00.json` — Attraction, attention and brain chemistry
- `content/2026-10-25/17-00.jpg` + `17-00.json` — Menstrual-period intimacy, consent and protection
- `content/2026-10-25/21-30.jpg` + `21-30.json` — Sexual desire across life and health factors

Each JSON contains `date`, `slot`, `topic`, `title`, detailed Hindi caption/description, hashtags, credible source references, and the exact repository-relative `image_path`.

## Upload and commit

Upload this ZIP to the repository root and commit it with a message such as:
`Add Jigyasa daily content package for 2026-10-25`

The ZIP already contains the `content/2026-10-25/` folder structure. Extract and commit that folder separately only if the publishing workflow requires the content files to be directly present in the repository tree.

## Validation

- Four distinct educational topics and four required slots.
- Four generated PNG source images were exported to high-quality JPEG without resizing or artificial file-size inflation.
- All JPGs and JSON files were checked for readability and expected metadata.
- The ZIP directory structure and member integrity were checked.
- Source links are included in each JSON. Review the educational artwork and captions before publishing.
