# Jigyasa Daily Package — 2026-10-27

This ZIP contains exactly four original AI-generated educational infographic posts for the Jigyasa Hindi/Hinglish page.

## Slots
- `08-00.jpg` + `08-00.json` — sleep and memory
- `13-00.jpg` + `13-00.json` — mangrove adaptations
- `17-00.jpg` + `17-00.json` — QR-code technology and safety
- `21-30.jpg` + `21-30.json` — the history of zero and place value

## Repository upload
Upload this ZIP file to the repository root and commit it as one daily package. Keep the `content/2026-10-27/` paths and image/JSON pairs unchanged. Do not split the package into separate ZIP files per post.

Each JSON includes the date, slot, topic, title, detailed Hindi caption, image description, hashtags, credible source references, and exact repository-relative image path.
