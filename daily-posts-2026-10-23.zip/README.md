# Jigyasa Daily Posts — 2026-10-23

This ZIP contains four separate educational infographic posts for 2026-10-23.

## Posts
- `content/2026-10-23/08-00.jpg` + `08-00.json` — किडनी और नेफ्रॉन
- `content/2026-10-23/13-00.jpg` + `13-00.json` — नींद और याददाश्त
- `content/2026-10-23/17-00.jpg` + `17-00.json` — पेड़ों में पानी का परिवहन
- `content/2026-10-23/21-30.jpg` + `21-30.json` — चंद्रमा की कलाएँ

Each JSON contains the India-time slot, topic, title, detailed Hindi caption, hashtags, alt text, credible source references, and repository-relative image path.

## Upload instructions
Upload this ZIP to the root of the Jigyasa repository and commit it according to the repository's existing workflow. The ZIP is not a single combined collage: it contains four separate JPG images and four matching JSON files.

## Image notes
The images were generated separately with ChatGPT image generation and exported as high-quality JPEGs at their original 1024 × 1536 resolution. Please review the rendered Hindi text and scientific labels before publishing, since image-generation systems can occasionally introduce text or diagram inaccuracies.
