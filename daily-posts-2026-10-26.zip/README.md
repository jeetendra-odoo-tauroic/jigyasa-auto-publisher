# Jigyasa Daily Package — 2026-10-26

This ZIP contains exactly four original educational infographic posts for the Jigyasa Hindi/Hinglish page.

## Slots
- `08-00.jpg` + `08-00.json` — wound healing
- `13-00.jpg` + `13-00.json` — pressure-cooker physics
- `17-00.jpg` + `17-00.json` — gecko adhesion
- `21-30.jpg` + `21-30.json` — Moon phases

## Repository upload
Upload this ZIP file to the repository root and commit it as one daily package. Keep the `content/2026-10-26/` paths and the image/JSON pairs unchanged. Do not split the package into separate ZIP files per post.

Each JSON includes the date, slot, topic, title, detailed Hindi caption, image description, hashtags, credible source references, and exact repository-relative image path.
