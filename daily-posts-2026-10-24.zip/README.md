# Jigyasa Daily Content Package — 2026-10-24

This ZIP contains four original Jigyasa educational infographic posts for 2026-10-24, with one JPG and one JSON sidecar per India-time publishing slot.

## Contents

- `content/2026-10-24/08-00.jpg` and `08-00.json` — Firefly light signals and courtship
- `content/2026-10-24/13-00.jpg` and `13-00.json` — Why chili feels hot
- `content/2026-10-24/17-00.jpg` and `17-00.json` — Early vaccine history and smallpox eradication
- `content/2026-10-24/21-30.jpg` and `21-30.json` — ABO blood-group inheritance

Each JSON includes the date, slot, topic, title, detailed Hindi caption/description, hashtags, source references, and the exact repository-relative `image_path`.

## Upload and commit

1. Download this ZIP and upload it to the repository root.
2. Commit the ZIP to the default branch with a message such as: `Add Jigyasa daily content package for 2026-10-24`.
3. Extract the ZIP in the repository only if the publishing workflow expects the `content/2026-10-24/` directory to be committed separately. The ZIP itself already contains that directory structure.

## Validation notes

- Four distinct topics across four different content categories.
- Four generated images were exported as high-quality JPEGs without resizing.
- All four JPGs and all four JSON sidecars were checked for readability and expected fields.
- Source URLs are included in each JSON. Please review the source notes and on-image text before publication.
